#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CSet �Ի���

class CSet : public CDialogEx
{
	DECLARE_DYNAMIC(CSet)

public:
	CSet(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSet();

// �Ի�������
	enum { IDD = IDD_SET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:

	CIPAddressCtrl m_ipAddressCtrl;

	char m_ip[16];

	BOOL isServer;

	afx_msg void OnBnClickedConnect();

	virtual BOOL OnInitDialog();

};
