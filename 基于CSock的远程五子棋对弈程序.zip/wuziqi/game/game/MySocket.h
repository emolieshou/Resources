#pragma once
#include "afxsock.h"

#define SOCKET_EVENT WM_USER + 1234

enum {ACCEPT=0,RECEIVE = 1,CLOSE = 2};

class CMySocket :
	public CSocket
{
public:
	CMySocket(void);
	~CMySocket(void);

	//����ָ��
	CWnd *pWnd;

	//�󶨴���
	void AttachCWnd(CWnd *pW);

	virtual void OnAccept(int nErrorCode);

	virtual void OnClose(int nErrorCode);

	virtual void OnReceive(int nErrorCode);

};

