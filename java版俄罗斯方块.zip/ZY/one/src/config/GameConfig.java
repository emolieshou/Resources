
/**
 * ��Ϸ����
 * ������ȡcfg.xml�ļ��ĸ�������
 * ������dom4j�ļ�
 */

package config;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class GameConfig {
	//��Ϸ���ڵĿ��Ⱥ͸߶�
	private int width;
	private int height;
	//��Ϸ�����ڵı߿����
	private int windowSize;
	//��Ϸ�����ڱ����λ��ƫ����
	private int padding;	
	private String title;
	//��������ֱƫ��������ʼֵΪ��
	private int windowup;
	private List<LayerConfig> layersConfig;
	
	public GameConfig() throws Exception{
		//newһ��xml��ȡ��
		SAXReader reader=new SAXReader();
		Document doc=reader.read("config/cfg.xml");
		//��ȡxml���ڵ�
		Element game=doc.getRootElement();	
		this.setUiConfig(game.element("frame"));
		this.setsystemConfig(game.element("system"));	
		this.setdataConfig(game.element("data"));		                   
	}
	
	private void setUiConfig(Element frame){
		//��ȡxml�ļ��еĸ������ݲ�����
		this.width=Integer.parseInt(frame.attributeValue("width"));
		this.height=Integer.parseInt(frame.attributeValue("height"));
		this.windowSize=Integer.parseInt(frame.attributeValue("windowSize"));
		this.padding=Integer.parseInt(frame.attributeValue("padding"));		
		this.title=frame.attributeValue("title");
		this.windowup=Integer.parseInt(frame.attributeValue("windowup"));
		//ע����elements��element
		@SuppressWarnings("unchecked")
		List<Element> layers=frame.elements("layer");	
		layersConfig=new ArrayList<LayerConfig>();
		for(Element layer:layers){
			LayerConfig lc=new LayerConfig(
					layer.attributeValue("className"),
					Integer.parseInt(layer.attributeValue("x")),
					Integer.parseInt(layer.attributeValue("y")),
					Integer.parseInt(layer.attributeValue("w")),
					Integer.parseInt(layer.attributeValue("h"))								
					);	
			layersConfig.add(lc);
		}		
	}
	
	private void setsystemConfig(Element frame){
		
	}
	private void setdataConfig(Element frame){
		
	}
	public int getWidth() {
		return width;
	}
	public int getHeight() {
		return height;
	}
	public int getWindowSize() {
		return windowSize;
	}
	public int getPadding() {
		return padding;
	}
	public List<LayerConfig> getLayersConfig() {
		return layersConfig;
	}	
	public String getTitle(){
		return title;
	}	
	public int getWindowUp(){
		return windowup;
	}
}
