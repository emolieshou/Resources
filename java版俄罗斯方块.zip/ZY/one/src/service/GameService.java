
/**
 * ��Ϸ�߼�
 */

package service;
import java.awt.Point;
import java.util.Random;
import dto.GameDto;
import entity.GameAct;

public class GameService {
	
	private Random random=new Random();
	private final static int MAX_TYPE=6;
	private GameDto dto;
	
	public GameService(GameDto dto){
		this.dto=dto;
		GameAct act=new GameAct(random.nextInt(MAX_TYPE));
		dto.setGameAct(act);
	}
	//�������
	public void keyUp() {
		this.dto.getGameAct().round(this.dto.getGameMap());
	}
	//�������
	public void keyDown() {
		if(this.dto.getGameAct().move(0, 1 ,this.dto.getGameMap())){
			return;
		}
	    boolean[][] map=this.dto.getGameMap();
		Point[] act=this.dto.getGameAct().getActPoints();
		for (int i = 0; i < act.length; i++) {
			map[act[i].x][act[i].y]=true;
		}
		this.MoveLine(map);
		this.dto.getGameAct().init(this.dto.getNext());
		this.dto.setNext(random.nextInt(MAX_TYPE));
	}
	//�������
	public void keyLeft() {
		this.dto.getGameAct().move(-1, 0,this.dto.getGameMap());
	}
	//�������
	public void keyRight() {
		this.dto.getGameAct().move(1, 0,this.dto.getGameMap());
	}
	// ���в���
	public void MoveLine(boolean[][] map) {
		for (int y = 17; y >= 0; y--) {
			if (this.isCanMove(map, y)) {
				this.remove(map, y);
				this.bb(map, y);
				y = 18;
			}
		}
	}
	// �жϵ�y���Ƿ��������
	public boolean isCanMove(boolean[][] map, int y) {
		for (int x = 0; x <= 9; x++) {
			if (!map[x][y]) {
				return false;
			}
		}
		return true;
	}
	// ��ȥ��y��
	private void remove(boolean[][] map, int y) {
		for (int x = 0; x <= 9; x++) {
			map[x][y] = false;
		}
		int point = this.dto.getNowPoint();
		int rmline = this.dto.getNowRemoveLine();
		int lv = this.dto.getNowLevel();
		point += 10;
		rmline += 1;
		if (rmline % 5 == 0) {
			lv += 1;
		}
		this.dto.setNowPoint(point);
		this.dto.setNowRemoveLine(rmline);
		this.dto.setNowLevel(lv);

	}
	// ���к�ʹ��Y��֮�����з����³�
	public void bb(boolean[][] map, int y) {

		for (int i = 0; i <= 9; i++) {
			int h = 0;
			for (int j = 17; j >= 0; j--) {
				if (map[i][j]) {
					h++;
				}
			}
			for (int j = 0; j < h; j++) {
				map[i][17 - j] = true;
			}
			for (int j = 0; j < 18 - h; j++) {
				map[i][j] = false;
			}
		}
	}
	
}
