
package main;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import javazoom.jl.player.Player;
 
public class MP3Player extends Thread{
	 
    private String filename;
    private Player player;
    
    public MP3Player(String filename) {
        this.filename = filename;
    }
 
    public void Play() {
        try {
            BufferedInputStream buffer = new BufferedInputStream(
                    new FileInputStream(filename));
            player = new Player(buffer);
            player.play();
        } catch (Exception e) {
            System.out.println(e);
        }
 
    }
    
    public void run(){
    	  MP3Player mp3 = new MP3Player(filename);
    	  while(true){
    		  mp3.Play();
    	  }
    }
}