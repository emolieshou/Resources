
/**
 * ��Ϸ��һ�д���
 */

package ui;
import java.awt.Graphics;

public class LayerNext extends Layer {
	
	public LayerNext(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		this.createWindow(g);
		//͸��
    	g.drawImage(Img.BACK,x+img_size, y+img_size, x-img_size+w, y-img_size+h, 0, 0, 100, 100, null);
		this.drawImageAtCenter(Img.Next_Act[this.dto.getNext()], g);
	}
}
