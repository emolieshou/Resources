
/**
 * ��Ϸ����
 */

package ui;
import java.awt.Graphics;
import javax.swing.ImageIcon;

public class LayerBackGround extends Layer {

	public LayerBackGround(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		int ImgIdx=this.dto.getNowLevel()%Img.BG_LIST.size();
		g.drawImage(new ImageIcon(Img.BG_LIST.get(ImgIdx)).getImage(), 0, 0,1162,654, null);
	}
}
