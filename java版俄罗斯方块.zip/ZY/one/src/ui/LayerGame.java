
/*
 * ��Ϸ������
 */

package ui;
import java.awt.Graphics;
import java.awt.Point;

public class LayerGame extends Layer {
	
	//��λ��ƫ����
	private static final int SIZE_ROL=5;
	//
	private static final int LEFT_SIDE=0;
	private static final int RIGHT_SIDE=9;

	public LayerGame(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		//͸��
    	g.drawImage(Img.BACK,x+img_size, y+img_size, x-img_size+w, y-img_size+h, 0, 0, 100, 100, null);
		Point points[] = this.dto.getGameAct().getActPoints();
		this.createWindow(g);
		// ��Ӱ
		this.drawshadow(points,true, g);
		this.drawMainAct(g);
		this.drawMap(points,g);	
	}
	
	private void drawMap(Point[] points,Graphics g) {
		int typeCode = this.dto.getGameAct().getTypeCode();
		for (int i = 0; i < points.length; i++) {
			this.drawActByPoint(points[i].x, points[i].y, typeCode + 1, g);
		}
	}
	
	private void drawMainAct(Graphics g) {
		boolean[][] map = this.dto.getGameMap();
		int lv = this.dto.getNowLevel();
		int imgIdx = lv == 0 ? 0 : (lv - 1) % 7 + 1;
		for (int x = 0; x < map.length; x++) {
			for (int y = 0; y < map[x].length; y++) {
				if (map[x][y]) {
					drawActByPoint(x, y, imgIdx, g);
				}
			}
		}
	}
	
	//������Ӱ                
	private void drawshadow(Point[] points, boolean isshadow,Graphics g) {
		if(!isshadow){
			return;
		}
		int rightX=LEFT_SIDE;
		int leftX=RIGHT_SIDE;
		for(Point po:points){	
			rightX=rightX<po.x?po.x:rightX;			
			leftX=leftX>po.x?po.x:leftX;
		}
		g.drawImage(Img.BACK_ACT, 
				    this.x+img_size+(leftX<<SIZE_ROL), this.y+img_size, 
				    (rightX-leftX+1)<<SIZE_ROL, this.h-(img_size<<1), 
				     null);		
	}
	
	private void drawActByPoint(int x,int y,int imgIdx,Graphics g){
		g.drawImage(Img.ACT, 
				this.x+(x<<SIZE_ROL)+7, 
				this.y+(y<<SIZE_ROL)+7, 
				this.x+((x+1)<<SIZE_ROL)+7, 
				this.y+((y+1)<<SIZE_ROL)+7,
			    (imgIdx)<<SIZE_ROL, 0, (imgIdx+1)<<SIZE_ROL, 32, null);
	}
}
