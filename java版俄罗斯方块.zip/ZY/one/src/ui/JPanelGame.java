
/**
 * ��Ϸ���
 */

package ui;
import java.awt.Graphics;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import config.ConfigFactory;
import config.GameConfig;
import config.LayerConfig;
import control.PlayerControl;
import dto.GameDto;

public class JPanelGame extends JPanel{
	
	private List<Layer> layers=null;
	private GameDto dto=null;
		
	public JPanelGame(GameDto dto){
		this.dto=dto;
		this.initLayer();
		this.initComponent();	
	}
	
	public void setGameControl(PlayerControl control){
		this.addKeyListener(control);
	}
	
	private void initComponent() {
//		Layer layer=this.layers.get(4);
//		this.setLayout(null);
//		JButton jb=new JButton();	
//		jb.setBounds(layer.x+layer.img_size+layer.PADDING, 72, 136, 50);
//		jb.setContentAreaFilled(false); 
//		jb.setIcon(new ImageIcon("Graphics/string/3.png"));
//	    jb.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//			}
//		});
//	    
//	       
//		JButton jbtwo=new JButton();
//		jbtwo.setBounds(layer.x+layer.img_size+layer.PADDING+136+layer.PADDING, 72, 136, 50);
//		jbtwo.setContentAreaFilled(false); 
//		jbtwo.setIcon(new ImageIcon("Graphics/string/ye.png"));
//		this.add(jb);
//		this.add(jbtwo);
	}
	
	//��ʼ��Layer
	private void initLayer(){
		try {
			GameConfig cfg=ConfigFactory.getGameConfig();
			List<LayerConfig> layersCfg=cfg.getLayersConfig();
			layers=new ArrayList<Layer>(layersCfg.size());
			for(LayerConfig layerCfg:layersCfg){
				//��������
				Class<?> cls=Class.forName(layerCfg.getClassName());
				Constructor<?> ctr=cls.getConstructor(int.class,int.class, int.class,int.class);
				Layer layer=(Layer)ctr.newInstance(
						layerCfg.getX(),layerCfg.getY(),
						layerCfg.getW(),layerCfg.getH()
						);
				layer.setDto(this.dto);
				layers.add(layer);
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void paintComponent(Graphics g){
		//���ø���ĳ����ʹ�����ú���Ҳ�еĺ���
		super.paintComponent(g);
		//ѭ��������Ϸ����
		for(int i=0;i<layers.size();i++){
			layers.get(i).paint(g);
		}
		//ʹ����ý���
		this.requestFocus();
	}
}
