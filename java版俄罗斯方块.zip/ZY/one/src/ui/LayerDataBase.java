/**
 * ��Ϸ���ݿⴰ��
 */

package ui;
import java.awt.Graphics;
import javax.swing.ImageIcon;

public class LayerDataBase extends Layer {
	
	public LayerDataBase(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		this.createWindow(g);		
		int ImgIdx=this.dto.getNowLevel()%Img.ND_LIST.size();
		g.drawImage(new ImageIcon(Img.ND_LIST.get(ImgIdx)).getImage(), 70, -120,null);
	}
}

