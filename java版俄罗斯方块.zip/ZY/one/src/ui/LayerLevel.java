
/*
 * ��Ϸ�ȼ�����
 */

package ui;
import java.awt.Graphics;

public class LayerLevel extends Layer {
	
	private static final int level_w=Img.LEVEL.getWidth(null);
	
	public LayerLevel(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		this.createWindow(g);
		//͸��
    	g.drawImage(Img.BACK,x+img_size, y+img_size, x-img_size+w, y-img_size+h, 0, 0, 100, 100, null);
		int centerx=this.w-level_w>>1;
		g.drawImage(Img.LEVEL, this.x+centerx, this.y+PADDING, null);
		this.drawImageLeftpad(centerx, 60,this.dto.getNowLevel(),2,g);
	}
}
