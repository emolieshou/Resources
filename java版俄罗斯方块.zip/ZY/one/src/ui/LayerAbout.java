
/**
 * ��Ϸ�����Ϣ
 */

package ui;
import java.awt.Graphics;

public class LayerAbout extends Layer {
	
	public LayerAbout(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		this.createWindow(g);
    	g.drawImage(Img.SIGN,this.x+this.img_size, this.y+this.img_size, this.w-this.img_size*2,this.h-this.img_size*2,null);
    	//͸��
    	g.drawImage(Img.BACK,this.x+this.img_size, this.y+this.img_size, this.w-this.img_size*2,this.h-this.img_size*2,null);
	}
}
