
package ui;

import java.awt.Graphics;

public class LayerDisk extends Layer {
	
	public LayerDisk(int x,int y,int w,int h){
		super(x,y,w,h);
	}
	
	public void paint(Graphics g) {
		this.createWindow(g);
		g.drawImage(Img.BACK,this.x, this.y, this.w,this.h-this.img_size,null);
		g.drawImage(Img.DISK, this.x, this.y, this.w,this.h-this.img_size,null);
	}
}
