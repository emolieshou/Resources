
/**
 * ������Ϸ���õ�������ͼƬ����
 */

package ui;
import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

public class Img {
	
	private Img(){}
	//����
	public static Image ACT=new ImageIcon("Graphics/game/rect.png").getImage();	
	//͸��
	public static Image BACK=new ImageIcon("Graphics/other/one.png").getImage();
	//��Ӱ
	public static Image BACK_ACT=new ImageIcon("Graphics/other/two.png").getImage();
	//��
	public static Image SIGN = new ImageIcon("Graphics/string/author.png").getImage();
	//����
	public static Image POINT=new ImageIcon("Graphics/string/point.png").getImage();
	//����
	public static Image RMLINE=new ImageIcon("Graphics/string/rmline.png").getImage();
	//����
	public static Image DISK=new ImageIcon("Graphics/string/disk.png").getImage();
	//�ȼ�
	public static Image LEVEL=new ImageIcon("Graphics/string/level.png").getImage();
	//����
	public static Image NUMBER=new ImageIcon("Graphics/string/num.png").getImage();
	//��ɫ����
	public static Image RECT=new ImageIcon("Graphics/window/rect.png").getImage();
	//�߿�(����д��·����ʵ���ޱ߿�)
	public static Image WINDOW=new ImageIcon("Graphics/Window/WindowOne.png").getImage();
	
	public static Image ZY=new ImageIcon("Graphics/string/ye.png").getImage();

	public static final Image[] Next_Act;
	
	public static final List<Image> BG_LIST;
	
	public static final List<Image> ND_LIST;
	
	static{
		Next_Act=new Image[7];
		for (int i = 0; i < Next_Act.length; i++) {
			Next_Act[i]=new ImageIcon("Graphics/game/"+i+".png").getImage();
		}
		File dir=new File("Graphics/background");
		File[] files=dir.listFiles();
		BG_LIST=new ArrayList<Image>();
		for(File file:files){
			if(!file.isDirectory()){
				BG_LIST.add(new ImageIcon(file.getPath()).getImage());
			}	
		}
		File dirTwo=new File("Graphics/ha");
		File[] filesTwo=dirTwo.listFiles();
		ND_LIST=new ArrayList<Image>();
		for(File file:filesTwo){
			if(!file.isDirectory()){
				ND_LIST.add(new ImageIcon(file.getPath()).getImage());
			}	
		}	
	}
}
