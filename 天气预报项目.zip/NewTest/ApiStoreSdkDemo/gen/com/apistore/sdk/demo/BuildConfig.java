/** Automatically generated file. DO NOT MODIFY */
package com.apistore.sdk.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}