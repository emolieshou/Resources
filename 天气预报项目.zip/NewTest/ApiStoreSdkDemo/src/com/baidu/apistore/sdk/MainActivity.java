package com.baidu.apistore.sdk;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.apistore.sdk.demo.R;
import com.baidu.apistore.sdk.network.Parameters;

/*
 * 测试前请在MyApplication.java中配置您的appkey
 */
public class MainActivity extends Activity {

	private TextView mTextView;

	private Button test;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		intUI();
	}

	private void intUI() {
		mTextView = (TextView) findViewById(R.id.mTextView);
		test = (Button) findViewById(R.id.test);
		test.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mTextView.setText("");
				apiTest();
			}
		});
	}

	private void apiTest() {
		Parameters para = new Parameters();
		// 根据城市拼音请求json数据
		para.put("city", "beijing");
		ApiStoreSDK.execute("http://apis.baidu.com/heweather/weather/free",
				ApiStoreSDK.GET, para, new ApiCallBack() {
					@Override
					// 以下三个函数为回调函数
					// 当数据请求成功时调用
					public void onSuccess(int status, String responseString) {
						mTextView.setText(responseString);
					}

					// 当数据请求完成时调用
					@Override
					public void onComplete() {

					}

					// 当数据请求出错时调用
					@Override
					public void onError(int status, String responseString,
							Exception e) {
						mTextView.setText(getStackTrace(e));
					}
				});
	}

	private String getStackTrace(Throwable e) {
		if (e == null) {
			return "";
		}
		StringBuilder str = new StringBuilder();
		str.append(e.getMessage()).append("\n");
		for (int i = 0; i < e.getStackTrace().length; i++) {
			str.append(e.getStackTrace()[i]).append("\n");
		}
		return str.toString();
	}
}
