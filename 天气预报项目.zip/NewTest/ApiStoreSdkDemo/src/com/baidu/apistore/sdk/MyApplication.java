package com.baidu.apistore.sdk;

import com.baidu.apistore.sdk.ApiStoreSDK;
import android.app.Application;

// 请在AndroidManifest.xml中application标签下android:name中指定该类
public class MyApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ApiStoreSDK.init(this, "9c8a232ab7f22f0c7e3b52a6e625d5d2");
    }
}
