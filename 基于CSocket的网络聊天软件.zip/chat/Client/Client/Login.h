#pragma once
#include "afxcmn.h"


// CLogin �Ի���

class CLogin : public CDialogEx
{
	DECLARE_DYNAMIC(CLogin)

public:
	CLogin(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLogin();

// �Ի�������
	enum { IDD = IDD_LOGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:

	CString m_name;

	afx_msg void OnBnClickedLogin();

	CIPAddressCtrl m_ipAddress;

	char m_ip[16];

	virtual BOOL OnInitDialog();
};
