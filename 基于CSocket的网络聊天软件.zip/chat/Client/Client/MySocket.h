#pragma once
#include "afxsock.h"

#define SOCKET_EVENT WM_USER + 1234

enum {RECEIVE = 0,CLOSE = 1};

class CMySocket :
	public CSocket
{
public:
	CMySocket(void);
	~CMySocket(void);

	//��������
	CWnd *pWnd;
	//�󶨴���
	void AttachCWnd(CWnd *pW);
	
	virtual void OnReceive(int nErrorCode);

	virtual void OnClose(int nErrorCode);

};

